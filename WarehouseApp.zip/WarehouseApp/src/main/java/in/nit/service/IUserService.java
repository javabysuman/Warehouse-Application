package in.nit.service;

import java.util.List;
import java.util.Optional;

import in.nit.model.User;

public interface IUserService {

	Integer saveUser(User user);
	List<User> getAllUsers();
	Optional<User> findByEmail(String email);
	int updateUserStatus(int status, Integer id);
}
